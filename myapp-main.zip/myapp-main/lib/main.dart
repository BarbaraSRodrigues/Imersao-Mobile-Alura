import 'package:flutter/material.dart';

// Onde começa a aplicação
void main() {
  // runApp roda o widget MyApp()
  runApp(const MyApp());
}

// StatelessWidget diz que é um widget
class MyApp extends StatelessWidget {
  // super.key é um identificador, então é interessante sempre colocar
  const MyApp({super.key});

  // Faz um overide no widget
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: HomeScreen());
  }
}

// stle é um atalho para criar tudo que é um widget
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Retorna a estrutura, ele deixa uma estrutura pronta
    return Scaffold(
      appBar: AppBar(
        title: Text("Meu Currículo", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepPurple,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Bárbara Rodrigues", style: TextStyle(fontSize: 32)),
            Text("Desenvolvedora FrontEnd"),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return Dialog(
                          child: Text("Envie um e-mail para Bárbara"),
                        );
                      },
                    );
                  },
                  child: Icon(Icons.send),
                ),
                TextButton(onPressed: () {}, child: Text("GitHub")),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
